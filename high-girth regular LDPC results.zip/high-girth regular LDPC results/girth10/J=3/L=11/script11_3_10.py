import subprocess
import shlex


for cir in range(576, 7, -1):
    cmd = 'SimulatedAnnealing.exe -seed 23132 -girth 10 -circulant ' + str(cir) + ' -numberOfMatrices 1 -regular 11 3'
    print(cmd)
    subprocess.call(cmd);
