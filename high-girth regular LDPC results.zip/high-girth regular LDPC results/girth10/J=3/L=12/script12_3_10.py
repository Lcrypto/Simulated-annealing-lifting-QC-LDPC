import subprocess
import shlex


for cir in range(757, 7, -1):
    cmd = 'SimulatedAnnealing.exe -seed 23132 -girth 10 -circulant ' + str(cir) + ' -numberOfMatrices 1 -regular 12 3'
    print(cmd)
    subprocess.call(cmd);
